<?php
	$str = '';
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$str = "Request POST";
	}
	elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
		$str = "Request GET";
	}
	elseif ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
		$str = "Request HEAD";
	}
	elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
		$str = "Request PUT";
	}
	elseif ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
		$str = "Request OPTIONS";
	}
	elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
		$str = "Request DELETE";
	}
	else $str = "Other Request";

	$file = '';
	if (!empty ($_FILES)) {
	    $file = $_FILES['file']['name'];
	}
?>

<html>
  <head>
    <title>MDS</title>
  </head>
  <body>

    <h1>Server response</h1>
    <p><?=$str ?></p>

    <h3>File name</h3>
    <p><?=$file ?></p>

  </body>
</html>